import { Component, ElementRef, HostListener, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { filter, Subject, take, takeUntil } from 'rxjs';

import { Router } from '@angular/router';
import { UserService } from './../../services/user.service';
import { SocketService } from 'src/app/services/socket.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
  // 🧩 Subscriptions & Cleanup
  private destroy$ = new Subject<void>();

  // 👥 Data
  userData: any;
  myChats: any[] = [];
  filteredFriends: any[] = [];
  onlineFriends: any[] = [];
  theChat: any[] = [];

  // 💬 Chat UI State
  chatItem = 'd-none';
  chat = 'chat';
  friend = '';
  searchStyle = 'd-none';
  settingStyle = 'd-none';
  theOpenedChatId: any;
  nameChat: string | null = null;
  imgChat: string | null = null;

  // ⏳ Loading / Error State
  isLoadingChat = false;
  isSendingMessage = false;
  chatError = '';
  actionError = '';
  fileError = '';

  // ✉️ Message Data
  message = '';
  editingMessage: any = null;
  profileUser: any = null;
  profileOpen = false;
  confirmation: { open: boolean; title: string; text: string; action: 'delete' | 'save-edit' | null; message?: any } = { open: false, title: '', text: '', action: null };
  searchTerm: any = '';

  // 📎 File handling
  selectedFile: File | null = null;
  filePreview: SafeUrl | null = null;
  fileType: 'image' | 'video' | 'pdf' | null = null;
  fileName: string | null = null;

  // 🎥 Video trimming
  videoUrl: SafeUrl | null = null;
  videoPreview: SafeUrl | null = null;
  videoBlobUrl: string | null = null;
  videoDuration = 0;
  trimStart = 0;
  trimEnd = 0;
activeList: any[] = [];
  // 🔈 Audio notification
  audio = new Audio('./assets/audio/ttn.mp3');

  @ViewChild('chatContainer') chatContainer!: ElementRef;

  constructor(
    private elem: ElementRef,
    private router: Router,
    private socketService: SocketService,
    private userService: UserService,
    private sanitizer: DomSanitizer
  ) {
  }

  // 🟢 Initialization
  ngOnInit(): void {
    // 📡 Listen for setting toggles
    //   this.clickEventSubscription = this.shareFunctions.getClickEvent().subscribe(() => {
    //   this.toggleSettings();
    // });
this.activeList = this.myChats; // الافتراضي هو عرض المحادثات
    // 👤 Listen for user data
    this.userService.user$
      .pipe(takeUntil(this.destroy$), filter(Boolean), take(1))
      .subscribe((data: any) => {
        this.userData = data;
        this.loadOnlineFriends();
        this.sortChats(data.chats);
this.searchFriends()
        // ⚡️ Connect to socket
        this.socketService.connect(this.userData._id);
        this.socketService.emit('join', this.userData._id);

        setTimeout(() => this.initializeSocketListeners(), 500);
      });
  }

  // 🧹 Cleanup
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.socketService.disconnect();
  }

  // 🧠 Socket Listeners
  initializeSocketListeners(): void {
    this.socketService.listen('receiveMessage').pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.userService.getUserData();
      this.handleIncomingMessage(data);
      setTimeout(() => this.scrollToBottom(true), 0);
    });

    this.socketService.listen('messagesRead').pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.theChat.forEach((msg) => (msg.isRead = true));
    });

    this.socketService.listen('messageUpdated').pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.applyUpdatedMessage(data?.message);
    });

    this.socketService.listen('messageDeleted').pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.applyDeletedMessage(data?.messageId, data?.chatId);
    });

    this.socketService.listen('presenceChanged').pipe(takeUntil(this.destroy$)).subscribe((data: any) => {
      this.applyPresenceChange(data?.userId, !!data?.isOnline);
    });
  }
  private idOf(value: any): string | undefined {
    return typeof value === 'string' ? value : value?._id;
  }
  // 💬 Handle Incoming Message
  handleIncomingMessage(data: any): void {
    const chatId = data.chatId ?? data.message?.chatId;
    const chatIndex = this.myChats.findIndex((chat) => chat._id === chatId);

    const senderId = this.idOf(data.message.sendBy);

    if (chatIndex === -1) {
      const newChat = {
        _id: chatId,
        participants: [data.message.sendBy, data.message.sendTo],
        lastMessage: data.message,
        unreadCount: senderId !== this.userData._id ? 1 : 0,
      };
      this.myChats.unshift(newChat);

      if (senderId === this.theOpenedChatId?._id) {
        this.theChat.push({ ...data.message, isRead: true });
        newChat.unreadCount = 0;
        if (chatId) this.markAsRead(chatId);
      }
    } else {
      const chat = this.myChats[chatIndex];
      chat.lastMessage = data.message;

      if (senderId === this.theOpenedChatId?._id) {
        this.theChat.push({ ...data.message, isRead: true });
        chat.unreadCount = 0;
        if (chatId) this.markAsRead(chatId);
      } else {
        chat.unreadCount = (chat.unreadCount || 0) + 1;
      }

      this.myChats.splice(chatIndex, 1);
      this.myChats.unshift(chat);
    }

    // 🔔 Play sound safely
    this.audio.pause();
    this.audio.currentTime = 0;
    this.audio.play().catch(() => {});
  }

  // ✅ Mark messages as read on the server
  markAsRead(chatId: string): void {
    if (!this.userData || !this.theOpenedChatId) return;
    this.socketService.emit('markAsRead', {
      chatId,
      readerId: this.userData._id,
      friendId: this.theOpenedChatId._id,
    });
  }

  // 👥 Load online friends
  loadOnlineFriends(): void {
    if (!this.userData?._id) return;
    this.userService
      .getOnlineFriends({ userId: this.userData._id })
      .subscribe((res: any) => (this.onlineFriends = res.onlineFriends));
  }

  // 🧾 Sort chats by latest message
  sortChats(chats: any[]): void {
    this.myChats = chats
      .map((chat) => ({
        ...chat,
        participants: chat.participants.filter(
          (p: any) => p._id !== this.userData._id
        ),
      }))
      .sort((a, b) => {
        if (!a.lastMessage || !b.lastMessage) return 0;
        const dateA = new Date(`${a.lastMessage.date} ${a.lastMessage.time}`);
        const dateB = new Date(`${b.lastMessage.date} ${b.lastMessage.time}`);
        return dateB.getTime() - dateA.getTime();
      });

    if (this.theOpenedChatId) {
      const i = this.myChats.findIndex(
        (c) => c.participants[0]._id === this.theOpenedChatId._id
      );
      if (i !== -1) this.myChats[i].unreadCount = 0;
    }

  }

  // 📂 Open Chat
  openChat(i: number, data: any[]): void {
    this.theChat = [];
    this.chatError = '';
    this.actionError = '';
    this.isLoadingChat = true;

    const myId = this.userData._id;
    const friendData = this.filteredFriends.length
      ? data[i]
      : data[i].participants[0];

    this.userService.getChat({ myId, friendId: friendData._id }).subscribe({
      next: (res: any) => {
        this.isLoadingChat = false;
        const chatData = res?.chat?.chat;
        this.theOpenedChatId = friendData;

        if (chatData) {
          this.theChat = chatData.messages.map(
            (msg: any, index: number, arr: any[]) => ({
              ...msg,
              showDivider: this.shouldShowDateDividerOnce(index, arr),
            })
          );

          setTimeout(() => this.scrollToBottom(true), 0);
          this.markAsRead(chatData._id);
          this.markMessagesAsRead();
        }

        // Update UI
        this.chat = '';
        this.searchStyle = 'd-none';
        this.friend = 'friend';
        this.chatItem = '';
        this.nameChat = friendData.userName;
        this.imgChat = friendData.profileImage;
      },
      error: () => {
        this.isLoadingChat = false;
        this.chatError = 'Unable to load this conversation. Please try again.';
      },
    });
  }

  // 📭 Mark all messages as read
  markMessagesAsRead(): void {
    this.userService
      .markMessagesAsRead({
        chatId: this.theOpenedChatId?._id,
        userId: this.userData._id,
      })
      .subscribe((res: any) => {
        if (res.success) {
          const chatIndex = this.myChats.findIndex(
            (c) => c.participants[0]._id === this.theOpenedChatId._id
          );
          if (chatIndex !== -1) this.myChats[chatIndex].unreadCount = 0;
        }
      });
  }


  handleNotificationSelected(notification: any): void {
    if (!notification) return;

    if (
      ['message', 'message_edited', 'message_deleted'].includes(notification.type) &&
      notification.data?.chatId
    ) {
      this.openChatFromNotification(notification);
      return;
    }

    if (
      notification.type?.startsWith('friend_request') ||
      notification.type === 'friend_removed'
    ) {
      this.router.navigate(['/settings/friends']);
    }
  }

  retryOpenChat(): void {
    const friend = this.theOpenedChatId;
    if (!friend?._id || !this.userData) return;

    this.chatError = '';
    this.openChatByFriend(friend);
  }

  private applyPresenceChange(userId: string | undefined, isOnline: boolean): void {
    if (!userId) return;

    this.myChats.forEach((chat) => {
      const participant = chat?.participants?.[0];
      if (participant?._id === userId) {
        participant.isOnline = isOnline;
      }
    });

    this.userData?.friends?.forEach((friend: any) => {
      if (friend?._id === userId) {
        friend.isOnline = isOnline;
      }
    });

    if (this.theOpenedChatId?._id === userId) {
      this.theOpenedChatId.isOnline = isOnline;
    }
  }

  private openChatFromNotification(notification: any): void {
    const chatId = notification.data?.chatId;
    if (!chatId) return;

    const openFromCurrentList = () => {
      const index = this.myChats.findIndex((chat) => chat._id === chatId);

      if (index !== -1) {
        this.openChat(index, this.myChats);
        return true;
      }

      return false;
    };

    if (openFromCurrentList()) return;

    this.userService.getMyChats({}).pipe(takeUntil(this.destroy$)).subscribe({
      next: (response: any) => {
        this.sortChats(response?.chats || []);
        this.activeList = this.myChats;
        openFromCurrentList();
      },
    });
  }

  // 📜 Scroll chat to bottom
  scrollToBottom(force: boolean = false): void {
    try {
      const container = this.chatContainer.nativeElement;
      const atBottom =
        container.scrollHeight - container.scrollTop - container.clientHeight <
        150;
      if (force || atBottom) container.scrollTop = container.scrollHeight;
    } catch {}
  }

  // 🚪 Close chat
  closeChat(): void {
    this.friend = '';
    this.chat = 'chat';
    this.chatItem = 'd-none';
    this.theOpenedChatId = undefined;
    this.nameChat = null;
    this.imgChat = null;
    this.theChat = [];
    this.chatError = '';
    this.actionError = '';
    this.cancelEdit();
    this.cancelPreview();
  }

  // ⚙️ Open the dedicated settings route.
  openSettings(): void {
    this.router.navigate(['/settings']);
  }

  // ✉️ Send message or file
  sendMessage(): void {
    if (this.editingMessage) {
      this.saveEditedMessage();
      return;
    }
    const content = this.message.trim();
    if (!content && !this.selectedFile) return;
    if (!this.theOpenedChatId || this.isSendingMessage) return;
    this.isSendingMessage = true;
    this.actionError = '';

    const formData = new FormData();
    formData.append('sendBy', this.userData._id);
    formData.append('sendTo', this.theOpenedChatId._id);
    formData.append('content', content || '');
    formData.append('date', new Date().toLocaleDateString('en-GB'));
    formData.append(
      'time',
      new Date().toLocaleTimeString('en-US', { hour12: false })
    );
    if (this.selectedFile) formData.append('file', this.selectedFile);

    this.userService.initChat(formData).subscribe({
      next: (res: any) => {
      this.isSendingMessage = false;
      this.cancelPreview();
      this.message = '';

      const newMsg = res.message;
      if (typeof newMsg.sendBy === 'string')
        newMsg.sendBy = { _id: newMsg.sendBy };
      if (typeof newMsg.sendTo === 'string')
        newMsg.sendTo = { _id: newMsg.sendTo };

      this.theChat.push(newMsg);
      setTimeout(() => this.scrollToBottom(true), 0);
      },
      error: () => {
        this.isSendingMessage = false;
        this.actionError = 'Message could not be sent. Please try again.';
      },
    });
  }


  // Message actions
  onMessageAction(event: { type: 'edit' | 'delete'; message: any }): void {
    if (event.type === 'edit') {
      if (!event.message?.content || event.message?.fileType) return;
      this.editingMessage = event.message;
      this.message = event.message.content;
      return;
    }

    this.confirmation = {
      open: true,
      title: 'Delete message?',
      text: 'This message will be removed from this conversation.',
      action: 'delete',
      message: event.message,
    };
  }

  saveEditedMessage(): void {
    const content = this.message.trim();
    if (!this.editingMessage || !content) return;
    this.confirmation = {
      open: true,
      title: 'Save changes?',
      text: 'The text of this message will be updated.',
      action: 'save-edit',
      message: this.editingMessage,
    };
  }

  confirmMessageAction(): void {
    const target = this.confirmation.message;
    if (!target) return;
    this.actionError = '';

    if (this.confirmation.action === 'delete') {
      this.userService.deleteMessage(target._id).subscribe({
        next: () => {
          this.applyDeletedMessage(target._id, target.chatId);
          this.closeConfirmation();
        },
        error: (error) => {
          this.actionError = error?.error?.message || 'Message could not be deleted. Please try again.';
          this.closeConfirmation();
        },
      });
      return;
    }

    if (this.confirmation.action === 'save-edit') {
      const content = this.message.trim();
      this.userService.updateMessage(target._id, content).subscribe({
        next: (response: any) => {
          const updated = response?.message;
          this.applyUpdatedMessage(updated || { ...target, content, isEdited: true });
          this.message = '';
          this.editingMessage = null;
          this.closeConfirmation();
        },
        error: (error) => {
          this.actionError = error?.error?.message || 'Message could not be updated. Please try again.';
          this.closeConfirmation();
        },
      });
      return;
    }

    this.closeConfirmation();
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.confirmation.open) {
      this.closeConfirmation();
      return;
    }
    if (this.profileOpen) {
      this.closeProfile();
      return;
    }
    if (this.mediaViewer.open) {
      this.closeMediaViewer();
    }
  }

  private applyUpdatedMessage(updatedMessage: any): void {
    if (!updatedMessage?._id) return;

    const index = this.theChat.findIndex((msg: any) => msg._id === updatedMessage._id);
    if (index !== -1) {
      this.theChat[index] = { ...this.theChat[index], ...updatedMessage, isEdited: true };
    }

    for (const chat of this.myChats) {
      if (chat?.lastMessage?._id === updatedMessage._id) {
        chat.lastMessage = { ...chat.lastMessage, ...updatedMessage, isEdited: true };
      }
    }
  }

  private applyDeletedMessage(messageId: string, chatId?: string): void {
    if (!messageId) return;

    const index = this.theChat.findIndex((msg: any) => msg._id === messageId);
    if (index !== -1) {
      this.theChat[index] = {
        ...this.theChat[index],
        content: '',
        fileUrl: null,
        fileType: null,
        isDeleted: true,
        isEdited: false,
      };
    }

    for (const chat of this.myChats) {
      if (chat?.lastMessage?._id === messageId) {
        chat.lastMessage = {
          ...chat.lastMessage,
          content: '',
          fileUrl: null,
          fileType: null,
          isDeleted: true,
          isEdited: false,
        };
      }
    }
  }

  closeConfirmation(): void {
    this.confirmation = { open: false, title: '', text: '', action: null };
  }

  cancelEdit(): void {
    this.editingMessage = null;
    this.message = '';
  }

  viewProfile(user: any): void {
    if (!user) return;
    this.profileUser = user;
    this.profileOpen = true;
  }

  closeProfile(): void {
    this.profileOpen = false;
    this.profileUser = null;
  }

  startChatFromProfile(user: any): void {
    const index = this.userData?.friends?.findIndex((friend: any) => friend._id === user?._id);
    if (index !== -1) {
      this.searchTerm = '';
      this.filteredFriends = [];
      this.activeList = this.myChats;
      this.openChatByFriend(user);
    }
  }

  private openChatByFriend(friend: any): void {
    this.theChat = [];
    this.userService.getChat({ myId: this.userData._id, friendId: friend._id }).subscribe({
      next: (res: any) => {
        this.isLoadingChat = false;
        const chatData = res?.chat?.chat;
        this.theOpenedChatId = friend;
        this.theChat = (chatData?.messages || []).map((msg: any, index: number, arr: any[]) => ({
          ...msg,
          showDivider: this.shouldShowDateDividerOnce(index, arr),
        }));
        this.chat = '';
        this.friend = 'friend';
        this.chatItem = '';
        this.nameChat = friend.userName;
        this.imgChat = friend.profileImage;
        this.profileOpen = false;
        setTimeout(() => this.scrollToBottom(true), 0);
      },
    });
  }

  // 📎 Handle file selection (image / video / pdf)
  async onFileSelected(event: any): Promise<void> {
    this.cancelPreview();
    this.fileError = '';
    const file = event.target.files?.[0];
    if (!file) return;

    this.selectedFile = file;
    this.fileName = file.name;
    const type = file.type;

    if (type.startsWith('image/')) {
      this.fileType = 'image';
      const reader = new FileReader();
      reader.onload = () =>
        (this.filePreview = this.sanitizer.bypassSecurityTrustUrl(
          reader.result as string
        ));
      reader.readAsDataURL(file);
    } else if (type.startsWith('video/')) {
      this.handleVideoFile(file);
    } else if (type === 'application/pdf') {
      this.fileType = 'pdf';
      const reader = new FileReader();
      reader.onload = () =>
        (this.filePreview = this.sanitizer.bypassSecurityTrustUrl(
          reader.result as string
        ));
      reader.readAsDataURL(file);
    } else {
      this.selectedFile = null;
      this.fileType = null;
      this.fileName = null;
      this.fileError = 'Only images, videos, or PDF files are supported.';
    }
  }

  // 🎥 Handle video logic
  handleVideoFile(file: File): void {
    const blobUrl = URL.createObjectURL(file);
    this.videoBlobUrl = blobUrl;
    const video = document.createElement('video');
    video.src = blobUrl;

    video.onloadedmetadata = () => {
      this.videoDuration = video.duration;

      if (video.duration > 600) {
        this.fileError = 'Videos longer than 10 minutes are not supported.';
        URL.revokeObjectURL(blobUrl);
        return;
      }

      this.fileType = 'video';
      const safeBlob = this.sanitizer.bypassSecurityTrustUrl(blobUrl);

      if (video.duration > 30) {
        this.videoUrl = safeBlob;
        this.videoPreview = null;
        this.trimStart = 0;
        this.trimEnd = video.duration;
      } else {
        this.videoUrl = safeBlob;
        this.videoPreview = safeBlob;
        this.filePreview = safeBlob;
      }
    };
  }

  // ✂️ Trim video
  async confirmTrim(): Promise<void> {
    if (!this.videoBlobUrl) return;
    const video = document.createElement('video');
    video.src = this.videoBlobUrl;

    await new Promise<void>(
      (resolve) => (video.onloadeddata = () => resolve())
    );
    const duration = Math.min(
      30,
      (this.trimEnd ?? this.trimStart + 30) - this.trimStart
    );
    const trimmedBlob = await this.trimVideoFrontend(
      video,
      this.trimStart,
      duration
    );

    const blobUrl = URL.createObjectURL(trimmedBlob);
    const safeBlob = this.sanitizer.bypassSecurityTrustUrl(blobUrl);

    this.videoPreview = safeBlob;
    this.filePreview = safeBlob;
    this.selectedFile = new File([trimmedBlob], 'trimmedVideo.webm', {
      type: 'video/webm',
    });
    this.videoUrl = null;
    this.videoDuration = 0;
  }

  // 🎞️ Actual trimming process
  async trimVideoFrontend(
    video: HTMLVideoElement,
    start: number,
    duration: number
  ): Promise<Blob> {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const recordedChunks: BlobPart[] = [];
      const stream = canvas.captureStream();
      const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });

      video.currentTime = start;
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };
      recorder.onstop = () =>
        resolve(new Blob(recordedChunks, { type: 'video/webm' }));

      video.onloadeddata = () => {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      };

      recorder.start();
      video.muted = true;
      video.play();

      const draw = () => {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        if (video.currentTime < start + duration && !video.ended)
          requestAnimationFrame(draw);
      };
      draw();

      setTimeout(() => {
        recorder.stop();
        video.pause();
        video.muted = false;
      }, duration * 1000);
    });
  }

  // 🧹 Cancel preview
  cancelPreview(): void {
    const revoke = (url: any) => {
      if (typeof url === 'string' && url.startsWith('blob:')) {
        try {
          URL.revokeObjectURL(url);
        } catch {}
      }
    };
    revoke(this.videoBlobUrl);
    this.videoBlobUrl = null;

    this.videoUrl = this.videoPreview = this.filePreview = null;
    this.fileType = this.selectedFile = this.fileName = null;
    this.fileError = '';
    this.videoDuration = 0;
  }

  // 🔍 Search
searchFriends() {
  const term = this.searchTerm.toLowerCase().trim();
  this.filteredFriends = term
    ? this.userData.friends.filter((f: any) =>
        f.userName.toLowerCase().includes(term)
      )
    : [];

  // نحدّد القائمة النشطة بناءً على وجود بحث
  this.activeList = term.length > 0 ? this.filteredFriends : this.myChats;
}

isChat(item: any): boolean {
  return !!item.lastMessage;
}

// جلب الصورة حسب نوع العنصر
getProfileImage(item: any): string {
  if (this.isChat(item)) {
    return item.participants[0]?.profileImage || 'default.png';
  } else {
    return item.profileImage || 'default.png';
  }
}

// جلب اسم المستخدم
getUserName(item: any): string {
  return this.isChat(item)
    ? item.participants[0]?.userName
    : item.userName;
}
  // 📅 Divider Logic
  shouldShowDateDividerOnce(index: number, messages: any[]): boolean {
    if (index === 0) return true;
    const current = messages[index];
    const previous = messages[index - 1];
    if (!current?.date || !previous?.date) return false;

    const parseDate = (d: string) => {
      const [day, month, year] = d.includes('/') ? d.split('/') : [0, 0, 0];
      return new Date(+year, +month - 1, +day);
    };

    return (
      parseDate(current.date).toDateString() !==
      parseDate(previous.date).toDateString()
    );
  }

  // 📆 Format Date Divider
  formatDateDivider(dateValue: any): string {
    if (!dateValue) return '';
    const [day, month, year] = dateValue.includes('/')
      ? dateValue.split('/')
      : ['', '', ''];
    const date = new Date(+year, +month - 1, +day);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';

    return date.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  }

  // ⏰ Format Time
  formatTime(value: any): string {
    if (!value) return '';
    if (value instanceof Date || !isNaN(Date.parse(value))) {
      const d = new Date(value);
      let h = d.getHours();
      const m = d.getMinutes().toString().padStart(2, '0');
      const ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
      return `${h}:${m} ${ampm}`;
    }
    const [hStr, m] = value.split(':');
    let h = parseInt(hStr, 10);
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
  }

  // 🖼️ Media Viewer
  mediaViewer = { open: false, url: '', type: '' };
  openMediaViewer(url: string, type: string): void {
    this.mediaViewer = { open: true, url, type };
  }
  closeMediaViewer(): void {
    this.mediaViewer.open = false;
  }
}
